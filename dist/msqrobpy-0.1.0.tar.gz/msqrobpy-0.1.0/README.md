# msqrobpy

`msqrobpy` is a Python-first, installable package inspired by the statistical design of `msqrob2` for quantitative LC-MS proteomics.

This implementation provides:

- per-feature ordinary least squares or robust linear modeling
- empirical-Bayes moderation of residual variances
- linear contrast testing with multiple-testing correction
- peptide-to-protein aggregation utilities
- a simple hurdle workflow combining abundance and detection models

It is deliberately Python-native and does **not** attempt to reproduce the Bioconductor object model.
